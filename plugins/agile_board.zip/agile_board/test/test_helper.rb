$VERBOSE = nil # hide ruby warning (move from 2 to 3 show several deprecations)

# Load the Redmine helper
require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')

ActiveRecord::FixtureSet.create_fixtures(File.dirname(__FILE__) + '/fixtures/', [
  :users,
  :issue_statuses,
  :trackers,
  :projects,
  :projects_trackers,
  :members,
  :member_roles,
  :roles,
  :issues,
  :enumerations,
  :workflows,
  :enabled_modules,
  :issue_relations,
  :journals,
  :journal_details,
  :versions,
  :custom_fields,
  :custom_fields_projects,
  :custom_fields_trackers,
  :custom_values,
  :time_entries])
