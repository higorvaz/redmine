require File.expand_path('../../test_helper', __FILE__)

class AgileBoardBurnupControllerTest < ActionController::TestCase
  fixtures :projects,
           :issue_statuses,
           :projects_trackers,
           :trackers,
           :users,
           :members,
           :roles,
           :member_roles,
           :workflows,
           :issues,
           :enabled_modules,
           :issue_relations,
           :journals,
           :journal_details,
           :versions,
           :custom_fields,
           :custom_fields_projects,
           :custom_fields_trackers,
           :custom_values

   def setup
     # Busca um usuário
     User.current = User.find(@request.session[:user_id] = 2)
     @project = projects(:projects_001)
   end

   def test_index
     get :index, params:  { project_id: @project.id }
     assert_response :success
     assert_select 'h2', I18n.t('burnup') + ' ' + @project.name
     assert_select 'div#div_burnup'
   end

   def test_index_project_with_version_without_effective_date
     projeto = projects(:projects_002)
     get :index, params:  { project_id: projeto.id }
     assert_response :success
     assert_select 'h2', I18n.t('burnup') + ' ' + projeto.name
     assert_select 'p#error_message', I18n.t('effective_date_not_set')
   end

end
