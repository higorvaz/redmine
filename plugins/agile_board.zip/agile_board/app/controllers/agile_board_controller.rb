class AgileBoardController < ApplicationController
  before_action :find_project_by_project_id, :authorize

  def index
    @statuses = Hash.new
    @issues = @project.issues
    @x_issues = []

    @issues.each do |flow|
      flow.custom_field_values.each do |cf|
        if cf.custom_field.name == "IssuePriorityOrder"
          @IssuePriorityOrder = cf.value
          @IssuePriorityID = cf.custom_field.id
        else
          @IssuePriorityOrder = 0
          @IssuePriorityID = ''
        end


      end
      @x_issues.push(
        id: flow.id,
        subject: flow.subject,
        status_id: flow.status_id,
        tracker_id: flow.tracker_id,
        priority: flow.priority,
        assigned_to: flow.assigned_to,
        fixed_version_id: flow.fixed_version_id,
        custom_field_values: flow.custom_field_values,
        IssuePriorityOrder: @IssuePriorityOrder.to_i,
        IssuePriorityID: @IssuePriorityID.to_i
      )
    end
    @x_issues = @x_issues.sort_by { |p| [-p[:IssuePriorityOrder]] }

    @project.trackers.each do |flow|
      flow.custom_fields.each do |cff|
        if cff.name == "Issue Kanban field"
          flow.issue_statuses.each do |status|
            @statuses[status.id] = status
          end
        end
      end
    end
  end

  def move_issue_update_status
    resposta = AgileBoardServices.new.move_issue_update_status(params[:issue_id], params[:new_status])
    render json: resposta.to_json
  end

  def change_card_color
    resposta = AgileBoardServices.new.change_card_color(params[:issue_id], params[:cf_id], params[:new_color])
    render json: resposta.to_json
  end

  def move_issue_update_position
    resposta = AgileBoardServices.new.move_issue_update_position(params[:issue_ids],params[:cf_id])
    render json: resposta.to_json
  end
end
