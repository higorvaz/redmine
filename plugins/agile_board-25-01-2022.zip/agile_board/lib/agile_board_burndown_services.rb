class AgileBoardBurndownServices

  def executar(project, current_version)
    return carregar_dados(project, current_version)
  end

  private
  Struct.new("Esforco", :data, :velocidade_ideal, :esforco_restante, :hora_trabalhada)
  Struct.new("Estimativa", :estimativa, :percentual_restante)
  Struct.new("OcorrenciaValor", :data, :valor)

    def carregar_dados(project, current_version)
      #Identifica as issues naquela versão
          issues = project.issues.select{|i| i.fixed_version_id == current_version.id}
      #Identifica os registros de esforço timelog
          timelog = project.time_entries
      #Cconsolidar os dados para formar o burndown
          data_inicial = issues.select {|i| !i.start_date.nil?}.map{|i| i[:start_date] }.min
          esforco = consolidar_dados_execucao(issues, timelog, data_inicial, current_version.effective_date) if !current_version.effective_date.nil? && !data_inicial.nil?
          esforco = [Struct::Esforco.new(Date.today, 0, 0, 0)] if esforco.nil?
          return esforco.map{|e| e.data.to_s},
                 esforco.map{|e| e.velocidade_ideal},
                 esforco.map{|e| e.esforco_restante},
                 esforco.map{|e| e.hora_trabalhada}
    end

    def consolidar_dados_execucao (issues, timelog, dt_ini, dt_fim)
      registro_esforco = calcular_esforco_por_dia(issues, dt_ini, dt_fim)
      calcular_velocidade_ideal(registro_esforco)
      calcular_hora_trabalhada(registro_esforco, issues, timelog)
      return registro_esforco
    end

    def calcular_esforco_por_dia(issues, dt_ini, dt_fim)
      registro_esforco = Array.new
      alteracao_estimativa = Array.new

      issues.each do |issue|
        alteracao_estimativa_por_issue = Array.new
        alteracao_percentual_restante_por_issue = Array.new
        issue.journals.each do |journal|
          journal.details.select{|d| d.property == 'attr' && (d.prop_key == 'estimated_hours' || d.prop_key == 'done_ratio')}.each do |journal_detail|
            alteracao_estimativa_por_issue.push(Struct::OcorrenciaValor.new(journal.created_on, journal_detail.old_value.to_f)) if journal_detail.prop_key == 'estimated_hours'
            alteracao_percentual_restante_por_issue.push(Struct::OcorrenciaValor.new(journal.created_on, (100 - journal_detail.old_value.to_f)/100)) if journal_detail.prop_key == 'done_ratio'
          end
        end
        alteracao_estimativa_por_issue.push(Struct::OcorrenciaValor.new(dt_fim.next_day, issue.estimated_hours.to_f))
        issue.done_ratio = 1.0 if issue.done_ratio.nil?
        alteracao_percentual_restante_por_issue.push(Struct::OcorrenciaValor.new(dt_fim.next_day, (100 - issue.done_ratio.to_f)/100))
        alteracao_estimativa.push(Struct::Estimativa.new(alteracao_estimativa_por_issue.sort_by{|e| e[:data]}.reverse, alteracao_percentual_restante_por_issue.sort_by{|e| e[:data]}.reverse))
      end

      (dt_ini .. dt_fim).each do |day|
        esforco = Struct::Esforco.new(day,0.0,0.0,0.0)
        alteracao_estimativa.each do |ed|
          esforco.esforco_restante = (esforco.esforco_restante + ed.estimativa.last.valor * ed.percentual_restante.last.valor).round(2)
          ed.estimativa.pop if ed.estimativa.last.data.to_date == day
          ed.percentual_restante.pop if ed.percentual_restante.last.data.to_date == day

        end
        registro_esforco.append(esforco)
      end
      return registro_esforco
    end

    def calcular_velocidade_ideal(registro_esforco)
      dias_fim_de_semana = (registro_esforco.first.data..registro_esforco.last.data).select{|d| [0,6].include?d.wday}
      dias_uteis = registro_esforco.count - dias_fim_de_semana.count
      esforco_total = registro_esforco.first.esforco_restante
      velocidade_ideal = esforco_total / dias_uteis

      registro_esforco.each do |registro|
        registro.velocidade_ideal = esforco_total.round(2)
        esforco_total -= velocidade_ideal if not dias_fim_de_semana.include? registro.data
      end
    end

    def calcular_hora_trabalhada(registro_esforco, issues, timelog)
      lista_issues = issues.map { |e| e.id }
      dias = registro_esforco.map {|r| r.data}
      horas_acumuladas = 0.0
      timelog.sort_by{|t| t.spent_on}.each do |entrada|
        if lista_issues.include? entrada.issue_id and dias.include? entrada.spent_on
          horas_acumuladas += entrada.hours
          registro_esforco.select{|registro| registro.data == entrada.spent_on.next_day}.first.hora_trabalhada = horas_acumuladas.round(2)
        end
      end
      horas_acumuladas = 0.0
      registro_esforco.each do |ht|
        ht.hora_trabalhada = horas_acumuladas if ht.hora_trabalhada < horas_acumuladas
        horas_acumuladas = ht.hora_trabalhada
      end
    end
end
