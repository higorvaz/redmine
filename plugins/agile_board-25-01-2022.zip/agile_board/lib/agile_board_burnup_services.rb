class AgileBoardBurnupServices
  def criar_burnup(project_id)
    return calcular_burnup(project_id)
  end

private
  Struct.new("Burnup", :versoes, :total_tarefas, :total_tarefas_concluidas, :esforco_total)
  Struct.new("Versao", :data_conclusao, :nome_versao, :tarefas_concluidas, :tarefas_existentes, :esforco_registrado)

  def calcular_burnup(project_id)
    burnup = consolidar_analise_versao_burnup(analisar_versoes(Project.find(project_id)))
    return [burnup.map{|b| b.versoes}, burnup.map{|b| b.total_tarefas}, burnup.map{|b| b.total_tarefas_concluidas}, burnup.map{|b| b.esforco_total}]
  end

  def consolidar_analise_versao_burnup(analise_versao)
    burnup = Array.new
    total_tarefas_concluidas = 0
    total_tarefas = 0
    esforco_total = 0.0

    analise_versao.each do |v|
      total_tarefas += v.tarefas_existentes
      total_tarefas_concluidas += v.tarefas_concluidas
      esforco_total += v.esforco_registrado
      burnup.push(Struct::Burnup.new(v.nome_versao, total_tarefas, total_tarefas_concluidas,  esforco_total))
    end
    return burnup
  end

# TODO: Excluir as releases que se encerram depois da data atual

  def analisar_versoes(projeto)
    lista_versoes = Array.new
    projeto.versions.each do |v|
      raise StandardError, I18n.t(:effective_date_not_set) if v.effective_date.nil?
      lista_versoes.push(registrar_tarefas(projeto, v.id, v.name, v.effective_date))
    end
    lista_versoes.push(registrar_tarefas(projeto, nil, "Ad hoc", Date.today))
    return lista_versoes.sort_by{|v| v.data_conclusao}
  end

  def registrar_tarefas(projeto, id, nome_versao, data_conclusao)
    lista_tarefas = projeto.issues.select { |i| i.fixed_version_id == id}
    tarefas_concluidas = lista_tarefas.select { |t| t.done_ratio == 100}.count
    esforco_realizado = calcular_esforco_versao(projeto, lista_tarefas)
    return Struct::Versao.new(data_conclusao, nome_versao, tarefas_concluidas, lista_tarefas.count, esforco_realizado)
  end

  def calcular_esforco_versao(projeto, lista_tarefas)
    esforco_realizado = 0.0
    timelog = projeto.time_entries
    lista_tarefas.each do |i|
      timelog.select{|t| t.issue_id == i.id}.each do |t|
        esforco_realizado += t.hours
      end
    end
    return esforco_realizado
  end

end
