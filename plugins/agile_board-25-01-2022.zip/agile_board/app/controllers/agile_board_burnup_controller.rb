class AgileBoardBurnupController < ApplicationController
  before_action :find_project_by_project_id, :authorize

  # Monta o burnup do projeto até o momento
  def index
    begin
      @burnup = AgileBoardBurnupServices.new.criar_burnup(params[:project_id])
    rescue StandardError => error_message
      @burnup = nil
      @burnup_error = error_message
    end
  end

end
