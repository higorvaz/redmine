require File.expand_path('../../test_helper', __FILE__)

class AgileBoardBurndownControllerTest < ActionController::TestCase
  fixtures :projects,
           :issue_statuses,
           :projects_trackers,
           :trackers,
           :users,
           :members,
           :roles,
           :member_roles,
           :workflows,
           :issues,
           :enabled_modules,
           :issue_relations,
           :journals,
           :journal_details,
           :versions,
           :custom_fields,
           :custom_fields_projects,
           :custom_fields_trackers,
           :custom_values

  def setup
    # Busca um usuário
    User.current = User.find(@request.session[:user_id] = 2)
    @project = projects(:projects_001)
  end

  def test_index
    get :index, params:  { project_id: @project.id }
    assert_response :success
    assert_select 'h2', I18n.t('burndown') + ' ' + @project.name
    assert_select 'div#div_burndown'
  end

  def test_change_release_version_com_datas_inicio_fim
    expected = "[[\"2020-08-01\",\"2020-08-02\",\"2020-08-03\",\"2020-08-04\",\"2020-08-05\",\"2020-08-06\",\"2020-08-07\",\"2020-08-08\",\"2020-08-09\",\"2020-08-10\",\"2020-08-11\",\"2020-08-12\",\"2020-08-13\",\"2020-08-14\"],[31.0,31.0,31.0,27.9,24.8,21.7,18.6,15.5,15.5,15.5,12.4,9.3,6.2,3.1],[31.0,31.0,31.0,30.0,25.0,25.0,25.0,25.0,25.0,25.0,25.0,25.0,25.0,25.0],[0.0,4.25,20.25,36.25,36.25,36.25,36.25,36.25,36.25,36.25,36.25,36.25,36.25,36.25]]"

    assert_generates '/agile_board_burndown/change_release_version', { controller: 'agile_board_burndown', action: 'change_release_version' }
    assert_not_equal expected, @response.body
    get :change_release_version, xhr: true, params: { project_id: @project.id, version_id: 3 }
    assert_equal "application/json", @response.media_type
    assert_equal expected, @response.body
  end

  def test_change_release_version_sem_data_inicio
    expected = ([[Date.today],[0],[0],[0]]).to_json

    get :change_release_version, xhr: true, params: { project_id: @project.id, version_id: 2 }
    assert_equal "application/json", @response.media_type
    assert_equal expected, @response.body
  end

  def test_change_release_version_sem_data_fim
    expected = ([[Date.today],[0],[0],[0]]).to_json
    projeto = projects(:projects_002)

    get :change_release_version, xhr: true, params: { project_id: projeto.id, version_id: 6 }
    assert_equal "application/json", @response.media_type
    assert_equal expected, @response.body
  end

  def test_change_release_version_em_aberto
    expected = ([[Date.today],[0],[0],[0]]).to_json

    get :change_release_version, xhr: true, params: { project_id: @project.id, version_id: 4 }
    assert_equal "application/json", @response.media_type
    assert_equal expected, @response.body
  end

  def test_fixture
    expected = constroi_array_resultado()

    get :change_release_version, xhr: true, params: { project_id: @project.id, version_id: 5 }
    assert_equal expected, @response.body
  end

private

  def constroi_array_resultado
    datas = []
    ideal = []
    estimado = [352.0,340.6,329.0,313.8,290.1,275.1,275.1,275.1,257.26,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31,224.31]
    trabalhado = [0.0,16.0,32.0,48.0,64.0,80.0,80.0,80.0,96.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0,112.0]

    dias_fim_de_semana = (9.days.ago.to_date..14.days.from_now.to_date).select{|d| [0,6].include?d.wday}
    dias_uteis = (9.days.ago.to_date..14.days.from_now.to_date).count - dias_fim_de_semana.count
    esforco = 352.0
    velocidade_ideal = esforco / dias_uteis

    (9.days.ago.to_date .. 14.days.from_now.to_date).each do |day|
      datas.push(day)
      ideal.push(esforco.round(2))
      esforco -= velocidade_ideal if not dias_fim_de_semana.include? day
    end
    return resultado = [datas,ideal,estimado,trabalhado].to_json
  end
end
