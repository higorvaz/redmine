require File.expand_path('../../../test_helper', __FILE__)

class AgileBoardBurnupServicesTest < ActiveSupport::TestCase
  fixtures :projects,
           :issue_statuses,
           :projects_trackers,
           :trackers,
           :users,
           :members,
           :roles,
           :member_roles,
           :workflows,
           :issues,
           :enabled_modules,
           :issue_relations,
           :journals,
           :journal_details,
           :versions,
           :custom_fields,
           :custom_fields_projects,
           :custom_fields_trackers,
           :custom_values

  def test_calcular_burnup
    expect = [["0.1", "0.2", "1.1", "1.0", "Ad hoc", "1.2"], [2, 3, 3, 5, 8, 14], [0, 0, 0, 0, 0, 2], [0.0, 0.0, 0.0, 36.25, 36.25, 148.25]]
    assert_equal expect, AgileBoardBurnupServices.new.criar_burnup(1)
  end

def test_calcular_burnup_raise_effective_date_exception
    assert_raise StandardError, I18n.t(:effective_date_not_set) do
      AgileBoardBurnupServices.new.criar_burnup(2)
    end
  end

end
