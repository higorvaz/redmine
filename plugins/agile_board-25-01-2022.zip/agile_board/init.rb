Redmine::Plugin.register :agile_board do
  name 'Agile Board plugin'
  author 'Bruno Nagano'
  description 'This plugin provides a kanban board to redmine'
  version '0.0.2'
#  url 'http://example.com/path/to/plugin'

  project_module :agile_board do
    permission :agile_board,                                  { :agile_board => [:index] }, :public => true
    permission :agile_board_move_issue_update_status,         { :agile_board => [:move_issue_update_status] }
    permission :agile_board_change_card_color,                { :agile_board => [:change_card_color] }
    permission :change_card_type_kanban_show,                { :agile_board => [:change_card_type_kanban_show] }
    permission :agile_board_burndown,                         { :agile_board_burndown => [:index] }, :public => true
    permission :agile_board_burndown_change_release_version,  { :agile_board_burndown => [:change_release_version] }, :public => true
    permission :agile_board_burnup,                           { :agile_board_burnup => [:index] }, :public => true
  end

  menu :project_menu, :agile_board_burnup, { :controller => 'agile_board_burnup', :action => 'index' }, :caption => 'Agile Burn Up', :after => :roadmap, :param => :project_id
  menu :project_menu, :agile_board_burndown, { :controller => 'agile_board_burndown', :action => 'index' }, :caption => 'Agile Burn Down', :after => :agile_board_burnup, :param => :project_id
  menu :project_menu, :agile_board, { :controller => 'agile_board', :action => 'index' }, :caption => 'Agile Board Kanban', :after => :agile_board_burndown, :param => :project_id
end

ActiveSupport::Dependencies.explicitly_unloadable_constants = 'agile_board'


module RedminePluginWithAssets
  module Hooks
  
    class IncludeJavascriptsHook < Redmine::Hook::ViewListener
      include ActionView::Helpers::TagHelper
      # https://www.redmine.org/projects/redmine/wiki/Hooks_List
      # view_issues_index_top
      #view_issues_new_top
      #view_issues_form_details_bottom
      #view_layouts_base_html_head
      def view_issues_form_details_bottom(context)
        javascript_include_tag(:application_agile, :plugin => 'agile_board')
      end
    end
  
  end
end