var board = document.getElementById('board');

var hideMe;

board.onselectstart = function(e) {
    e.preventDefault();
}

board.ondragstart = function(e) {
    console.log('dragstart');
    hideMe = e.target;
    e.dataTransfer.setData('atividade', e.target.id);
    e.dataTransfer.effectAllowed = 'move';
};

board.ondragend = function(e) {
    e.target.style.visibility = 'visible';
};

var lastEntered;

board.ondragenter = function(e) {
    console.log('dragenter');
    if (hideMe) {
        hideMe.style.visibility = 'hidden';
        hideMe = null;
    }
    lastEntered = e.target;
    var section = closestWithClass(e.target, 'section');
    if (section) {
        section.classList.add('droppable');
        e.preventDefault(); // Not sure if these needs to be here. Maybe for IE?
        return false;
    }
};

board.ondragover = function(e) {
    if (closestWithClass(e.target, 'section')) {
        e.preventDefault();
    }
};

board.ondragleave = function(e) {
    if (e.target.nodeType === 1) {
        var section = closestWithClass(e.target, 'section');
        if (section && !section.contains(lastEntered)) {
            section.classList.remove('droppable');
        }
    }
    lastEntered = null; // No need to keep this around.
};

board.ondrop = function(e) {
    console.log('ondrop');
    var section = closestWithClass(e.target, 'section');
    var id = e.dataTransfer.getData('atividade');
    if (id) {
        var issue = document.getElementById(id);
        if (issue) {
            if (section !== issue.parentNode) {
                var project_id = document.getElementById('projeto').getAttribute('data-project-id');
		var section_id = section.getAttribute('data-section-id');
		$.ajax({
			url: "/agile_board/move_issue_update_status",
			type: 'POST',
			data: {project_id: project_id, issue_id: issue.id, new_status: section_id},
			success: function(r){
                if (r[0] == true)
                    section.appendChild(issue);
                else displayErrorMessage(r[1]);
			},
			error: function(r){
        displayErrorMessage("Você não tem permissão para mover o cartão para a atividade!");
			}
		});
            }
        } else {
            displayErrorMessage('couldn\'t find issue #' + id);
        }
    }
    section.classList.remove('droppable');
    e.preventDefault();
};

function closestWithClass(target, className) {
    while (target) {
        if (target.nodeType === 1 &&
            target.classList.contains(className)) {
            return target;
        }
        target = target.parentNode;
    }
    return null;
}