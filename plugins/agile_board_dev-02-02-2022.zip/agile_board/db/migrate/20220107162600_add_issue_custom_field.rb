class AddIssueCustomField < ActiveRecord::Migration[5.2]
  def change
    if IssueCustomField.find_by_name('Issue Kanban field').nil?
      IssueCustomField.create(name: 'Issue Kanban field', field_format: 'bool', is_required: false, editable: true, default_value: 'true', is_for_all: true, description: 'Store agile_board issue show')
    else
      IssueCustomField.find_by_name('Issue Kanban field').delete
    end
  end
end
