class AddColorCustomField < ActiveRecord::Migration[5.2]
  def change
    if IssueCustomField.find_by_name('Card color field').nil?
      IssueCustomField.create(name: 'Card color field', field_format: 'string', is_required: false, editable: true, default_value: '#ff8', is_for_all: true, description: 'Store agile_board card color')
    else
      IssueCustomField.find_by_name('Card color field').delete
    end
  end
end