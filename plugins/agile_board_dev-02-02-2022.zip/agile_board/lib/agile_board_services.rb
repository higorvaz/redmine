class AgileBoardServices

  def change_card_color(issue_id, cf_id, new_color)
    issue = Issue.find(issue_id)
    return [false, I18n.t(:cf_disabled)] if not verify_cf_card_color_enabled(Tracker.find(issue.tracker_id))
    old_color = issue.custom_field_value(cf_id)
    issue.custom_field_values = { cf_id => new_color }
    issue.transaction do
      if record_color_change_journal(issue, old_color, new_color, cf_id) && issue.save
        return [true]
      else
        return [false, I18n.t(:update_db_error)]
      end
    end
  end

  def move_issue_update_position(issue_ids)
    return [true]
  end
    # issue = Issue.find(issue_id)
    # return [false, I18n.t(:cf_disabled)] if not verify_cf_card_type_enabled(Tracker.find(issue.tracker_id))
    # old_value = issue.custom_field_value(cf_id)
    # issue.custom_field_values = { cf_id => new_value }
    # issue.transaction do
    #   if record_color_change_journal(issue, old_value, new_value, cf_id) && issue.save
    #     return [true]
    #   else
    #     return [false, I18n.t(:update_db_error)]
    #   end
    # end
  # end

  def move_issue_update_status(issue_id, new_status)
    issue = Issue.find(issue_id)
    return [false, I18n.t(:ilegal_move)] if not issue.new_statuses_allowed_to(User.current).find { |issue_status| issue_status.id == new_status.to_i }
    Issue.transaction do
      if record_status_change_journal(issue, new_status.to_i) && issue.update(status_id: new_status.to_i)
        # return [true]
        true
      else
        exit [false, I18n.t(:update_db_error)]
      end
    end
  end

  private

  def verify_cf_card_color_enabled(tracker)
    tracker.custom_fields.each do |cf|
      return true if cf.name == "Card color field"
    end
    return false
  end
  def verify_cf_card_type_enabled(tracker)
    tracker.custom_fields.each do |cf|
      return true if cf.name == "Issue Kanban field"
    end
    return false
  end

  def record_change_journal(property, prop_key, old_value, new_value, issue, notes = "")
    journal ||= Journal.create(journalized: issue, user: User.current, notes: notes, notify: false)
    journal.details << JournalDetail.new(property: property, prop_key: prop_key, old_value: old_value, value: new_value) if journal
    return journal.save
  end

  def record_status_change_journal(issue, new_status_id)
    return record_change_journal('attr', 'status_id', issue.status_id, new_status_id, issue)
  end

  def record_color_change_journal(issue, old_color, new_color, cf_id)
    return record_change_journal('cf', cf_id, old_color, new_color, issue)
  end
end
