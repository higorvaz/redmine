class AgileBoardController < ApplicationController
  before_action :find_project_by_project_id, :authorize

  def index

    @statuses = Hash.new

    @issues = @project.issues

    @project.trackers.each do |flow|

      flow.custom_fields.each do |cff|
        if cff.name == 'Issue Kanban field' then
          flow.issue_statuses.each do |status|
            @statuses[status.id] = status
          end
        end
      end
    end
    
  end

  def move_issue_update_status
    resposta = AgileBoardServices.new.move_issue_update_status(params[:issue_id], params[:new_status])
    render json: resposta.to_json
  end

  def change_card_color
    resposta = AgileBoardServices.new.change_card_color(params[:issue_id], params[:cf_id], params[:new_color])
    render json: resposta.to_json
  end

  def move_issue_update_position
    resposta = AgileBoardServices.new.move_issue_update_position(params[:issue_ids])
    render json: resposta.to_json
  end

end

