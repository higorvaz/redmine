// var board = document.getElementById("board");

// $(".section").sortstart = function (e) {
//   e.preventDefault();
//   console.log("sortstart ", e);
// };


var project_id = document
.getElementById("projeto")
.getAttribute("data-project-id");
//*[@id="8"]

$(".section")
.sortable({
  connectWith: ".section",
  items: ".atividade",
  
  start: function (event, ui) {
    // console.log("ui ", ui);
    // console.log("event ", event);
    // var orderArray = $(this).sortable("toArray");
    // console.log("orderArray ", orderArray);   
  },
  
  stop: function (event, ui) {
    // console.log("ui ", ui);
    // console.log("event ", event);
    // var orderArray = $(this).sortable("toArray");
    // console.log("orderArray ", orderArray);
  },
  
  update: function (event, ui) {
    var issue_id = ui.item[0].id;
    var position_id = $("div[data-cf-position_id]").attr("data-cf-position_id");
    var sectionTarget = $(this)[0].dataset.sectionId;
    var orderArray = $(this).sortable("toArray");
    
      // console.log("ui ", ui);
      // console.log("event ", event);
      // console.log("orderArray ", orderArray);
      
      if (ui.sender) {
        console.log("ui.sender ", ui.sender);
        stageChange(sectionTarget, project_id, issue_id);
      } else {
        orderArray = $(this).sortable("toArray");
        console.log("ui.sender ", ui.sender);
        console.log("orderArray ", orderArray);
        orderChange(orderArray, project_id, position_id);
      }
    },
  })
  .disableSelection();

function stageChange(section_id, project_id, issue_id) {
  $.ajax({
    url: "/agile_board/move_issue_update_status",
    type: "POST",
    data: {
      project_id: project_id,
      issue_id: issue_id,
      new_status: section_id,
    },
    success: function (r) {
      // if (r[0] == true)
      // displayErrorMessage("stageChange success ",r);
      console.log("stageChange success ", r);
    },
    error: function (r) {
      displayErrorMessage(
        "Você não tem permissão para mover o cartão para a atividade!"
      );
    },
  });
}
function orderChange(o, p, c) {
  $.ajax({
    url: "/agile_board/move_issue_update_position",
    type: "POST",
    data: {
      issue_ids: o,
      project_id: p,
      cf_id: c,
    },

    success: function (r) {
      // if (r[0] == true) displayErrorMessage("stageChange success ", r);

      console.log("orderChange success ", r);
    },
    error: function (r) {
      displayErrorMessage(
        "Você não tem permissão para mudar a prioridade do cartão!"
      );
    },
  });
}
/*
  $('.section').sortable({/agile_board/move_issue_update_status
    // axis: 'x',
    // connectWith: ".section",
    // items: ".atividade",
    // update: function (event, ui) {
    //     var data = $(this)[0].dataset ;
    //     console.log('data ',data);
    //     // POST to server using $.post or $.ajax
    //     $.ajax({
    //         data: 'data',
    //         type: 'POST',
    //         url: '/your/url/x'
    //     });event, ui 
    // },

    // axis: 'y',
    items: ".atividade",
    connectWith: ".section",
    update: function( event, ui ) {

      // item[0].sortableItem.direction item[0].jQuery351089046319624208462.sortableItem.direction
      //[0].jQuery351068644625966120982.uiSortables
      
      // console.log('$(this) ',$(this));
      // console.log('$(this).iSortable ',$(this).uiSortable);
      // console.log('$(this)[0].uiSortable ',$(this)[0].uiSortable);
      // console.log('$(this)[0][0] ',$(this)[0][0]);
      // console.log('ui.item[0] ',ui.item[0]);
      // console.log('ui.item ',ui.item[0][1]);
      
      console.log('ui ',ui);
      console.log('event ',event);
    },
    // update: function (event, ui) {
    //     var data = $(this) ;
    //     console.log('data ',data);
    //     var dataset = $(this)[0].dataset;
    //     console.log('dataset ',dataset);
    //     // POST to server using $.post or $.ajax
    //     $.ajax({
    //         data: 'data',
    //         type: 'POST',
    //         url: '/your/url/y'
    //     });
    // }
}).disableSelection();
//   $('.section').sortable({
//     axis: 'y',
//     connectWith: ".section",
//     items: ".atividade",
//     update: function (event, ui) {
//         var data = $(this).sortable('serialize');
//         console.log('data ',data);
//         // POST to server using $.post or $.ajax
//         $.ajax({
//             data: data,
//             type: 'POST',
//             url: '/your/url/y'
//         });
//     }
// });

// $(document).ready(function () {
// $(".section").sortable({
//   connectWith: ".section",
//   items: ".atividade",
//   handle: ".atividade",
//   update: function () {
//     var order = $(".section").sortable("serialize");
//     $("#info").load("process-sortable.php?" + order);
//   },
// });
// });
*/

/*

// var hideMe;

// board.onselectstart = function (e) {
//   e.preventDefault();
// };

board.ondragstart = function (e) {
  console.log("dragstart");
  hideMe = e.target;
  e.dataTransfer.setData("atividade", e.target.id);
  e.dataTransfer.effectAllowed = "move";
};

board.ondragend = function (e) {
  e.target.style.visibility = "visible";
};

var lastEntered;

board.ondragenter = function (e) {
  console.log("dragenter");
  if (hideMe) {
    hideMe.style.visibility = "hidden";
    hideMe = null;
  }
  lastEntered = e.target;
  var section = closestWithClass(e.target, "section");
  if (section) {
    section.classList.add("droppable");
    e.preventDefault(); // Not sure if these needs to be here. Maybe for IE?
    return false;
  }
};

board.ondragover = function (e) {
  if (closestWithClass(e.target, "section")) {
    e.preventDefault();
  }
};

board.ondragleave = function (e) {
  if (e.target.nodeType === 1) {
    var section = closestWithClass(e.target, "section");
    if (section && !section.contains(lastEntered)) {
      section.classList.remove("droppable");
    }
  }
  lastEntered = null; // No need to keep this around.
};

board.ondrop = function (e) {
  console.log("ondrop ", e);

  var section = closestWithClass(e.target, "section");
  var id = e.dataTransfer.getData("atividade");

  console.log(id);
  console.log(section);

  if (id) {
    var issue = document.getElementById(id);
    if (issue) {
      if (section !== issue.parentNode) {
        var project_id = document
          .getElementById("projeto")
          .getAttribute("data-project-id");
        var section_id = section.getAttribute("data-section-id");
        $.ajax({
          url: "/agile_board/move_issue_update_status",
          type: "POST",
          data: {
            project_id: project_id,
            issue_id: issue.id,
            new_status: section_id,
          },
          success: function (r) {
            if (r[0] == true) section.appendChild(issue);
            else displayErrorMessage(r[1]);
          },
          error: function (r) {
            displayErrorMessage(
              "Você não tem permissão para mover o cartão para a atividade!"
            );
          },
        });
      }
    } else {
      displayErrorMessage("couldn't find issue #" + id);
    }
  }

  section.classList.remove("droppable");
  e.preventDefault();
};

function closestWithClass(target, className) {
  while (target) {
    if (target.nodeType === 1 && target.classList.contains(className)) {
      return target;
    }
    target = target.parentNode;
  }
  return null;
}





// $( ".section" ).sortable( {
//       connectWith: ".section",
//       items: ".atividade"
//     }).disableSelection();

// $( function(e) {
//   $( ".section" ).sortable( {
//     connectWith: ".section",
//     items: ".atividade"
//   }).disableSelection();
//   var from,to;
//   $(this).on("sortstart",function(e,ui){
//       e.preventDefault();
//         from = sortstart$(this).children().index(ui.item);

//         console.log("dragstart");
//         hideMe = e.target;
//         e.dataTransfer.setData("atividade", e.target.id);
//         e.dataTransfer.effectAllowed = "move";

//         // console.log('e ',$(this));



//     });
//     $(this).on('sortdeactivate',function(event,ui) {
//         to = $(this).children().index(ui.item);
//         // alert(ui.item.text()+' moved from '+(from + 1)+' to '+(to + 1));
//     });
// } );

// here is how you can detect dragging in all four directions
// var isDragging = false;
// $("section").mousedown(function(e) {
//     var previous_x_position = e.pageX;
//     var previous_y_position = e.pageY;
//     $( "#sortable1, #sortable2" ).sortable({
//       connectWith: ".connectedSortable"
//     }).disableSelecti
//     $(window).mousemove(function(event) {
//         isDragging = true;
//         var x_position = event.pageX;
//         var y_position = event.pageY;

//         if (previous_x_position < x_position) {
//             alert('moving right');
//         } else {
//             alert('moving left');
//         }
//         if (previous_y_position < y_position) {
//             alert('moving down');
//         } else {
//             alert('moving up');
//         }
//         $(window).unbind("mousemove");
//     });
// }).mouseup(function() {
//     var wasDragging = isDragging;
//     isDragging = false;
//     $(window).unbind("mousemove");
// });
*/
