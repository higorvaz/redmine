require File.expand_path('../../test_helper', __FILE__)

class AgileBoardControllerTest < ActionController::TestCase
  fixtures :projects,
           :issue_statuses,
           :projects_trackers,
           :trackers,
           :users,
           :members,
           :roles,
           :member_roles,
           :workflows,
           :issues,
           :enabled_modules,
           :issue_relations,
           :journals,
           :journal_details,
           :versions,
           :custom_fields,
           :custom_fields_projects,
           :custom_fields_trackers,
           :custom_values

  def setup
    # Busca um usuário
    User.current = User.find(@request.session[:user_id] = 2)
    @project = projects(:projects_001)
  end

  def test_index
    get :index, params:  { project_id: @project.id }
    assert_response :success
    assert_select 'h2', I18n.t('board') + ' ' + @project.name
    assert_select 'select#versoes'
    assert_select 'select#usuarios'
    assert_select 'select#tipos'
    assert_select 'div#board'

    issues = @project.issues
#    workflow = @project.trackers.visible(User.current)
    @project.trackers.each do |tracker|
      tracker.custom_fields.each do |cff|
        if cff.name == 'Issue Kanban field' then
          tracker.issue_statuses.each do |issue_status|
            assert_select 'div#'+issue_status.name.gsub(/\s+/, "").downcase
            issues.where(:status_id => issue_status.id).each do |issue|
              assert_select 'div#'+issue.id.to_s
            end
          end
        end
      end
    end
  end

  def test_move_issue_cannot_change_status
    assert_generates '/agile_board/move_issue_update_status', { controller: 'agile_board', action: 'move_issue_update_status' }
    assert_equal Issue.find(1).status_id, 1
    post :move_issue_update_status, xhr: true, params: { project_id: @project.id, issue_id: 1, new_status: 2 }
    assert_equal Issue.find(1).status_id, 1
    assert_equal "application/json", @response.media_type
    assert_equal false, JSON.parse(@response.body)[0]
  end

  def test_move_issue_can_change_status
    assert_equal Issue.find(2).status_id, 2
    post :move_issue_update_status, xhr: true,  params: { project_id: @project.id, issue_id: 2, new_status: 3 }
    assert_equal Issue.find(2).status_id, 3
    assert_equal "application/json", @response.media_type
    assert_equal true, JSON.parse(@response.body)[0]

    # check if changelog was altered
    assert_equal 1, Issue.find(2).journals.count

    Issue.find(2).journals.each do |j|
      j.details.each do |d|
        assert_equal 2, d.old_value.to_i
        assert_equal 3, d.value.to_i
        assert_equal 'status_id', d.prop_key
      end
    end

  end

  def test_change_card_color
    assert_generates '/agile_board/change_card_color', {controller: 'agile_board', action: 'change_card_color' }
    assert_equal '#000088', return_card_color_value(Issue.find(3).custom_field_values)
    post :change_card_color, xhr: true, params: { project_id: @project.id, issue_id: 3, new_color: '#FFFFFF', cf_id: 1 }

    assert_equal "application/json", @response.media_type
    assert_equal true, JSON.parse(@response.body)[0]
    assert_equal '#FFFFFF', return_card_color_value(Issue.find(3).custom_field_values)
  end

  def test_error_change_card_color_no_custom_field
    assert_equal '#FFFF88', return_card_color_value(Issue.find(8).custom_field_values)
    post :change_card_color, xhr: true, params: { project_id: @project.id, issue_id: 8, new_color: '#FFFFFF', cf_id: nil }
    assert_equal false, JSON.parse(@response.body)[0]
    assert_equal 'Custom field \'Card Color\' has not been enabled for this tracker.', JSON.parse(@response.body)[1]
    assert_equal '#FFFF88', return_card_color_value(Issue.find(8).custom_field_values)
  end

  private

  def return_card_color_value(cf_list)
    cf_list.each do |cf|
      if cf.custom_field.name == 'Card color field'
        return cf.value.to_s
      end
    end
    return '#FFFF88'
  end

end