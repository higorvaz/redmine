# Agile Board for Redmine

**Developer:** Bruno Nagano
**Company:** Tribunal Regional Federal da 1º Região
**Description:** Yet another agile board plugin for Redmine. 

## Installation Instructions:
Clone or copy the plugin to the plugins folder `<redmine_root>\plugins`.

**Migrate the Database**
From the `<redmine_root>` folder execute `rails redmine:plugins:migrate`

**Observation:**
Make sure the custom field "Card color field" is active for the trackers in use in the project.
