class AgileBoardBurndownController < ApplicationController
  before_action :find_project_by_project_id, :authorize

  # Seleciona a versão atual com base na data, se não tiver pega a última
  def index
    @burndown = nil
    project = Project.find(params[:project_id])
    current_version = project.versions.select{|v| !v.effective_date.nil? && v.effective_date > Date.today}.sort_by{|d| d.effective_date}[0]
    current_version = project.versions.max if current_version.nil?
    if !current_version.nil?
      @id_version = current_version.id if !current_version.nil?
      @burndown = AgileBoardBurndownServices.new.executar(project, current_version)
    end
  end

  # Seleciona a versão atual com base na seleção do usuário
  def change_release_version
    burndown = nil
    project = Project.find(params[:project_id])
    current_version = project.versions.find(params[:version_id])
    burndown = AgileBoardBurndownServices.new.executar(project, current_version)
    render json: burndown
  end
end
