# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html

get  '/agile_board',                                  to: 'agile_board#index'
post '/agile_board/move_issue_update_status',         to: 'agile_board#move_issue_update_status'
post '/agile_board/change_card_color',                to: 'agile_board#change_card_color'
post '/agile_board/move_issue_update_position',       to: 'agile_board#move_issue_update_position'
get  '/agile_board_burndown',                         to: 'agile_board_burndown#index'
get  '/agile_board_burndown/change_release_version',  to: 'agile_board_burndown#change_release_version'
get  '/agile_board_burnup',                           to: 'agile_board_burnup#index'